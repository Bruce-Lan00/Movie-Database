Name: Bruce Lan(Tianchen Lan) 101177179
      Xiuling Pan             101093034


Sumbit files: 
Note: all the files below are stored in the single file "project-checkin-brucelan&xiulingpan.zip"
[folder]： css ->css files
          
          database ->json files

          views -> pug files   
 
[files]:  server.js      
          
          package.json, package-lock.json

          Detail Outline of Data Model.pdf 
          RESTful Design.pdf

          README.txt
          


Instructions: 0. (make sure you have installed express and pug), then
              1. run "node server.js" in your command prompt to connect to the server
              2. search for "http://localhost:3000" in your browser
              


(Thank you for your time :D )
         